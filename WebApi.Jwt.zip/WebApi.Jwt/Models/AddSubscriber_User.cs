﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace WebApi.Jwt.Models
{
    public class AddSubscriber_User
    {
        public string code { get; set; }
        public string Message { get; set; }
        //public string LastNameTH { get; set; }
       // public string CitizenID { get; set; }
    }
    class democlass
    {
        public string oid;
     
     public   string namedemo { get; set; }
    }

}
